from django.contrib import admin

from .models import perpus

admin.site.register(perpus)